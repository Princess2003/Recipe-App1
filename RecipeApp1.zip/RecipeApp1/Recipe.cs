﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp1
{
     class Recipe
    {
        private Ingredient[] ingredients;  // Array to store ingredients
        private RecipeApp.Step[] steps;  // Array to store steps

        // Constructor to initialize a recipe object with given number of ingredients and steps
        public Recipe(int numIngredients, int numSteps)
        {
            ingredients = new Ingredient[numIngredients];
            steps = new RecipeApp.Step[numSteps];
        }

        // Method to add an ingredient to the recipe at a specific index
        public void AddIngredient(int index, string name, double quantity, string unit)
        {
            ingredients[index] = new Ingredient(name, quantity, unit);
        }

        // Method to add a step to the recipe at a specific index
        public void AddStep(int index, string description)
        {
            steps[index] = new RecipeApp.Step(description);
        }

        // Method to display the recipe including ingredients and steps
        public void DisplayRecipe()
        {
            Console.WriteLine("Recipe:");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i].Description}");
            }
        }

        // Method to scale the recipe by a given factor
        public void ScaleRecipe(double factor)
        {
            foreach (var ingredient in ingredients)
            {
                ingredient.Quantity *= factor;
            }
        }

        // Method to reset ingredient quantities to their original values
        public void ResetQuantities()
        {
            // Reset quantities to original values
        }

        // Method to clear the recipe data
        public void ClearRecipe()
        {
            // Clear all data to enter a new recipe
        }
    }

}

    
