﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp1
{
      class Step
    {
        public string Description { get; set; }  // Description of the step

        // Constructor to initialize a step object with provided description
        public Step(string description)
        {
            Description = description;
        }

    }
}
