﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp1
{
    class Ingredient
    {
        public string Name { get; set; }  // Name of the ingredient
        public double Quantity { get; set; }  // Quantity of the ingredient
        public string Unit { get; set; }  // Unit of measurement for the ingredient

        // Constructor to initialize an ingredient object with provided values
        public Ingredient(string name, double quantity, string unit)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
        }
    }
}
