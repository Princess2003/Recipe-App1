﻿namespace RecipeApp
{
    internal class Step
    {
        private string description;

        public Step(string description)
        {
            this.description = description;
        }

        public object Description { get; internal set; }
    }
}