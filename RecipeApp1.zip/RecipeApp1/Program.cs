﻿
using RecipeApp1;
using System;

namespace RecipeApp
{

    // Main program class
    class Program
    {
        // Main method
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Recipe App!");

            // Variables to hold recipe data
            int numIngredients, numSteps;
            Recipe recipe = null;

            // Main menu loop
            while (true)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Create a new recipe");
                Console.WriteLine("2. Display recipe");
                Console.WriteLine("3. Scale recipe");
                Console.WriteLine("4. Reset quantities");
                Console.WriteLine("5. Clear recipe");
                Console.WriteLine("6. Exit");

                Console.Write("Select an option: ");
                string choice = Console.ReadLine();

                // Switch statement to handle user choices
                switch (choice)
                {
                    case "1":
                        // Get user input for number of ingredients and steps
                        Console.Write("Enter the number of ingredients: ");
                        numIngredients = int.Parse(Console.ReadLine());

                        Console.Write("Enter the number of steps: ");
                        numSteps = int.Parse(Console.ReadLine());

                        // Create a new recipe
                        recipe = new Recipe(numIngredients, numSteps);

                        // Get user input for ingredients
                        for (int i = 0; i < numIngredients; i++)
                        {
                            Console.Write($"Enter the name of ingredient {i + 1}: ");
                            string name = Console.ReadLine();

                            Console.Write($"Enter the quantity of {name}: ");
                            double quantity = double.Parse(Console.ReadLine());

                            Console.Write($"Enter the unit of measurement for {name}: ");
                            string unit = Console.ReadLine();

                            recipe.AddIngredient(i, name, quantity, unit);
                        }

                        // Get user input for steps
                        for (int i = 0; i < numSteps; i++)
                        {
                            Console.Write($"Enter step {i + 1}: ");
                            string description = Console.ReadLine();

                            recipe.AddStep(i, description);
                        }
                        break;

                    case "2":
                        if (recipe != null)
                            recipe.DisplayRecipe();
                        else
                            Console.WriteLine("No recipe created yet!");
                        break;

                    case "3":
                        if (recipe != null)
                        {
                            Console.Write("Enter scale factor (0.5, 2, or 3): ");
                            double factor = double.Parse(Console.ReadLine());
                            recipe.ScaleRecipe(factor);
                            Console.WriteLine("Recipe scaled successfully!");
                        }
                        else
                        {
                            Console.WriteLine("No recipe created yet!");
                        }
                        break;

                    case "4":
                        if (recipe != null)
                        {
                            recipe.ResetQuantities();
                            Console.WriteLine("Quantities reset to original values.");
                        }
                        else
                        {
                            Console.WriteLine("No recipe created yet!");
                        }
                        break;

                    case "5":
                        recipe = null;
                        Console.WriteLine("Recipe cleared.");
                        break;

                    case "6":
                        Console.WriteLine("Exiting... Goodbye!");
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please select again.");
                        break;
                }
            }
        }
    }
}
